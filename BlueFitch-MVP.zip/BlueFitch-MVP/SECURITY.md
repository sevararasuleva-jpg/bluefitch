
# Security Policy

Do not include any personal data or bank customer information. For issues, open a private security advisory rather than a public issue.
