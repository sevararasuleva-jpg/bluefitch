
import sys, csv, math

def pmt(rate_month, nper, pv):
    if rate_month == 0:
        return -(pv / nper)
    return -(pv * rate_month * (1 + rate_month)**nper) / ((1 + rate_month)**nper - 1)

def apr_from_nominal_month(rate_month):
    return (1 + rate_month)**12 - 1

if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "data/sample_products.csv"
    with open(path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            if row["product_type"] != "loan":
                continue
            term = int(row["term_months_max"])
            amount = float(row["amount_min"])
            r_nom_annual = float(row["rate_nominal_pct"]) / 100.0
            r_month = r_nom_annual / 12.0
            pay = pmt(r_month, term, amount)
            apr = apr_from_nominal_month(r_month)
            print(f"{row['product_id']} {row['bank_name']}: PMT≈{abs(pay):.2f}, APR/EIR≈{apr*100:.2f}%")
