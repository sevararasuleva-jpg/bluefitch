
# Contributing

- Keep data columns consistent with `README.md`.
- Validate formulas in Google Sheets and mirror checks in `scripts/`.
- Do not commit private bank contracts or credentials.
