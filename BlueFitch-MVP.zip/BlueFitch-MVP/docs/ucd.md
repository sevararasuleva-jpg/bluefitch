
# User-Centered Design Notes

- Primary user: consumer choosing a loan/deposit quickly and safely.
- Key flows:
  1. Select product type (loan/deposit/BNPL).
  2. Set amount, term, currency; apply filters.
  3. Sort by "Most advantageous" (score_advantage).
  4. Open card → see transparent breakdown, AI explanation.
  5. Compare up to 3 products, save/share.
- Accessibility & language: UZ/RU/EN.
