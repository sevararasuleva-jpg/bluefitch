
# Architecture (MVP)

- **Frontend / UI:** Lovable (mobile-first). Components: product list, filters, product card, compare (up to 3), AI chat widget.
- **Data Source:** Google Sheets as live table with pre-computed fields (PMT, APR/EIR, total_cost, score_advantage). Sync via Lovable data connectors or CSV export.
- **AI Assistant:** system prompt explains hidden fees in plain language (UZ/RU/EN) and justifies comparisons with numbers from pre-computed columns.
- **Validation:** optional Python script (`scripts/calc_finance.py`) to spot-check PMT/EIR vs. Sheets.
