
# BlueFitch — AI‑powered Fintech Comparison MVP

**Purpose.** Help users in Uzbekistan find the most transparent and cost‑effective banking products (loans, deposits, BNPL) by comparing offers from multiple banks. The built‑in AI assistant explains hidden fees and effective rates in simple language (UZ/RU/EN).

**Stack.** No‑/low‑code MVP built on **Lovable**, with **Google Sheets** as a live data source (pre‑computed formulas for APR/EIR/PMT/total cost) and optional Python utilities for verification.

---

## ✨ Program Application Brief (copy‑paste)

**Project:** BlueFitch — AI‑powered fintech comparison platform  
**Purpose:** BlueFitch helps users find the most transparent and cost‑effective loans and deposits, explaining hidden fees and effective rates via an AI assistant.  
**My role:** I designed the product, built the MVP on Lovable, and created the multi‑language data architecture in Google Sheets with pre‑computed formulas (APR, PMT, total cost, advantage score).  
**Main technical challenge:** Connecting dynamic spreadsheet formulas to a no‑code web UI with reliable, real‑time calculations and multilingual outputs. I solved this by structuring the dataset, pre‑computing key metrics, and syncing it to Lovable with validation scripts.  
**GitHub:** https://github.com/BlueFitch-MVP (placeholder)

---

## Data Model (CSV)

See [`data/sample_products.csv`](data/sample_products.csv). Core columns:

```
product_id, bank_name, product_type, currency, term_months_min, term_months_max, amount_min, amount_max, rate_nominal_pct, rate_type, fees_upfront, fees_monthly, fees_insurance, fees_sms, early_repayment_policy, hidden_fees_notes, lang, pmt_month, total_cost, apr_effective_pct, yield_effective_pct, score_advantage
```

### Google Sheets formulas (examples)

- **Monthly payment (PMT)**  
  `=PMT(rate_nominal_pct/12, term_months, -amount)`

- **Effective annual rate (APR / EIR) approximation**  
  If monthly rate in cell `r_m`:  
  `=((1 + r_m)^12 - 1)`

- **Total cost (principal + interest + fees)**  
  `=term_months * pmt_month + fees_upfront + term_months * (fees_monthly + fees_sms) + fees_insurance`

- **Score advantage (0–100)** (toy example)  
  `=ROUND(100 - (apr_effective_pct*50) - (fees_upfront/amount*100) + IF(early_repayment_policy="flexible",10,0), 1)`

> In production, replace with your audited formula.

---

## Folder Structure

```
.
├── ai/
│   └── assistant_prompt.md
├── data/
│   └── sample_products.csv
├── docs/
│   ├── architecture.md
│   └── ucd.md
├── scripts/
│   └── calc_finance.py
├── .gitignore
├── LICENSE
└── README.md
```

---

## Quick Start (for verification scripts)

```bash
python3 scripts/calc_finance.py data/sample_products.csv
```

This prints PMT and EIR/APR checks so you can compare with Google Sheets outputs.

---

## Roadmap

- [ ] Bank connectors / data ingestion
- [ ] Validation suite comparing Sheets vs script calculations
- [ ] Multilingual copy (UZ/RU/EN)
- [ ] Public demo link (Lovable)
- [ ] Privacy & compliance notes
- [ ] Unit tests

---

## License

MIT — see `LICENSE`.
